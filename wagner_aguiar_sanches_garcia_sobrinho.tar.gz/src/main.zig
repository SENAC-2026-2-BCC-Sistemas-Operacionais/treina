const std = @import("std");

pub fn main(init: std.process.Init) !void {
	try std.Io.File.stdout().writeStreamingAll(
		init.io,
		"Wagner Aguiar Sanches Garcia Sobrinho\n",
	);
}
